function validateForm(){
  let empName = document.forms["frmCollectWeights"]["empName"];
  let empWeight = document.forms["frmCollectWeights"]["empWeight"];
  //
  if (empName.value == "") {
    return false;
  }
  if (empWeight.value == "") {
    return false;
  }
  //
  return true;
}
